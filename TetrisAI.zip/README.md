TetrisAI
Requirements.txt will contain all packages needed for the environment.